<?php
const DB_HOST = 'localhost';
const DB_USER = 'blog';
const DB_PASSWORD = 'blog';
const DB_NAME = 'blog';
